function myFunction() {
  document.getElementById("demo").innerHTML = "Paragraph Changed";
  document.getElementById("demo").style.color = "red";
  document.getElementById("demo").style.fontSize = "25px";
  document.getElementById("demo").style.fontFamily = "Source Sans Pro regular";
}

var Person = {
  firstName: "ZAHID",
  lastName: "Hasan",
  Age: 29,
  Nationality: "Bangladeshi"
};

var a =
  Person.firstName +
  " " +
  Person.lastName +
  " is " +
  Person.Age +
  " years old" +
  " and he is " +
  Person.Nationality;
console.log(a);
